//  import React, { useState } from 'react'
// import { Link } from 'react-router-dom'
// import {
//   CButton,
//   CCard,
//   CCardBody,
//   CCardGroup,
//   CCol,
//   CContainer,
//   CForm,
//   CFormInput,
//   CInputGroup,
//   CInputGroupText,
//   CRow,
// } from '@coreui/react'
// import CIcon from '@coreui/icons-react'
// import { cilLockLocked, cilUser } from '@coreui/icons'

// const Login = () => {
//   const [username, setUsername] = useState('');
//   const [showOtpButton, setShowOtpButton] = useState(false);

//   const handleUsernameChange = (e) => {
//     setUsername(e.target.value);
//     if (e.target.value) {
//       setShowOtpButton(true);
//     } else {
//       setShowOtpButton(false);
//     }
//   };

//   const handleSendOtp = () => {
//     alert("OTP sent!");
//   };

//   return (
//     <div className="bg-body-tertiary min-vh-100 d-flex flex-row align-items-center">
//       <CContainer>
//         <CRow className="justify-content-center">
//           <CCol md={8}>
//             <CCardGroup>
//               <CCard className="p-4">
//                 <CCardBody>
//                   <CForm>
//                     <h1>Login</h1>
//                     <p className="text-body-secondary">Sign In to your account</p>
//                     <CInputGroup className="mb-3">
//                       <CInputGroupText>
//                         <CIcon icon={cilUser} />
//                       </CInputGroupText>
//                       <CFormInput 
//                         placeholder="Admin Name" 
//                         autoComplete="adminname" 
//                       />
//                     </CInputGroup>
//                     <CInputGroup className="mb-3">
//                       <CInputGroupText>
//                         <CIcon icon={cilUser} />
//                       </CInputGroupText>
//                       <CFormInput 
//                         placeholder="Username" 
//                         autoComplete="username" 
//                         value={username} 
//                         onChange={handleUsernameChange} 
//                       />
//                     </CInputGroup>
//                     {showOtpButton && (
//                       <CRow className="mb-3">
//                         <CCol xs={12} className="text-center">
//                           <CButton color="primary" onClick={handleSendOtp}>
//                             Send OTP
//                           </CButton>
//                         </CCol>
//                       </CRow>
//                     )}
//                     <CInputGroup className="mb-4">
//                       <CInputGroupText>
//                         <CIcon icon={cilLockLocked} />
//                       </CInputGroupText>
//                       <CFormInput
//                         type="password"
//                         placeholder="Password"
//                         autoComplete="current-password"
//                       />
//                     </CInputGroup>
//                     <CRow>
//                       <CCol xs={6}>
//                         <CButton color="primary" className="px-4">
//                           Login
//                         </CButton>
//                       </CCol>
//                       <CCol xs={6} className="text-right">
//                         <CButton color="link" className="px-0">
//                           Forgot password?
//                         </CButton>
//                       </CCol>
//                     </CRow>
//                   </CForm>
//                 </CCardBody>
//               </CCard>
//               <CCard className="text-white bg-primary py-5" style={{ width: '44%' }}>
//                 <CCardBody className="text-center">
//                   <div>
//                     <h2>Sign up</h2>
//                     <p>
//                       Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
//                       tempor incididunt ut labore et dolore magna aliqua.
//                     </p>
//                     <Link to="/register">
//                       <CButton color="primary" className="mt-3" active tabIndex={-1}>
//                         Register Now!
//                       </CButton>
//                     </Link>
//                   </div>
//                 </CCardBody>
//               </CCard>
//             </CCardGroup>
//           </CCol>
//         </CRow>
//       </CContainer>
//     </div>
//   )
// }

// export default Login
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  CButton,
  CCard,
  CCardBody,
  CCardGroup,
  CCol,
  CContainer,
  CForm,
  CFormInput,
  CInputGroup,
  CInputGroupText,
  CRow,
} from '@coreui/react';
import CIcon from '@coreui/icons-react';
import { cilUser } from '@coreui/icons';

const Login = () => {
  const [mobileNumber, setMobileNumber] = useState('');
  const [showOtpButton, setShowOtpButton] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState('');
  const navigate = useNavigate();

  const handleMobileNumberChange = (e) => {
    const value = e.target.value;
    if (/^\d{0,10}$/.test(value)) {
      setMobileNumber(value);
      if (value.length === 10) {
        setShowOtpButton(true);
      } else {
        setShowOtpButton(false);
      }
    }
  };

  const handleSendOtp = () => {
    setOtpSent(true);
    alert("OTP sent!");
  };

  const handleOtpChange = (e) => {
    setOtp(e.target.value);
  };

  const handleSubmitOtp = () => {
    if (otp.length === 4) {
      navigate('/dashboard');
    } else {
      alert("Please enter a valid 4-digit OTP");
    }
  };

  return (
    <div className="bg-body-tertiary min-vh-100 d-flex flex-row align-items-center">
      <CContainer>
        <CRow className="justify-content-center">
          <CCol md={8}>
            <CCardGroup>
              <CCard className="p-4">
                <CCardBody>
                  <CForm>
                    <h1>Login</h1>
                    <p className="text-body-secondary">Enter Mobile Number to Generate OTP</p>
                    <CInputGroup className="mb-3">
                      <CInputGroupText>
                        <CIcon icon={cilUser} />
                      </CInputGroupText>
                      <CFormInput 
                        placeholder="Mobile Number" 
                        autoComplete="tel" 
                        value={mobileNumber} 
                        onChange={handleMobileNumberChange} 
                        maxLength={10}
                      />
                    </CInputGroup>
                    {showOtpButton && (
                      <CRow className="mb-3">
                        <CCol xs={12} className="text-center">
                          <CButton color="primary" onClick={handleSendOtp}>
                            Send OTP
                          </CButton>
                        </CCol>
                      </CRow>
                    )}
                    {otpSent && (
                      <>
                        <CInputGroup className="mb-3">
                          <CInputGroupText>OTP</CInputGroupText>
                          <CFormInput 
                            type="text" 
                            placeholder="Enter 4-digit OTP" 
                            value={otp} 
                            onChange={handleOtpChange} 
                            maxLength={4} 
                          />
                        </CInputGroup>
                        <CButton color="primary" onClick={handleSubmitOtp}>
                          Submit OTP
                        </CButton>
                      </>
                    )}
                  </CForm>
                </CCardBody>
              </CCard>
              <CCard className="text-white bg-primary py-5" style={{ width: '44%' }}>
                <CCardBody className="text-center">
                  <div>
                    <h2>Sign up</h2>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                      tempor incididunt ut labore et dolore magna aliqua.
                    </p>
                    <Link to="/register">
                      <CButton color="primary" className="mt-3" active tabIndex={-1}>
                        Register Now!
                      </CButton>
                    </Link>
                  </div>
                </CCardBody>
              </CCard>
            </CCardGroup>
          </CCol>
        </CRow>
      </CContainer>
    </div>
  );
};

export default Login;

