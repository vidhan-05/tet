import { cilPencil, cilTrash } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import {
  CButton,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CCollapse,
  CForm,
  CFormInput,
  CFormLabel,
  CPagination,
  CPaginationItem,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
} from '@coreui/react'
import axios from 'axios'
import { format } from 'date-fns'
import React, { useEffect, useState } from 'react'
import { IoToggle } from 'react-icons/io5'
import { getBackendURL } from '../../../util'
const formatDateForDisplay = (dateString) => {
  if (!dateString) return ''

  const date = new Date(dateString)
  const day = String(date.getDate()).padStart(2, '0')
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const year = date.getFullYear()

  return `${day}-${month}-${year}`
}

const calculateAge = (dateOfBirth) => {
  const today = new Date()
  const birthDate = new Date(dateOfBirth)
  let age = today.getFullYear() - birthDate.getFullYear()
  const monthDifference = today.getMonth() - birthDate.getMonth()

  // If the current month is before the birth month, or it's the birth month but the day is before the birth day, subtract one year from age
  if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
    age--
  }

  return age
}

const getMaxDateOfBirth = () => {
  const today = new Date()
  const maxDate = new Date(today.setFullYear(today.getFullYear() - 18))
  return maxDate.toISOString().split('T')[0] // Format as YYYY-MM-DD
}

const formatTimeForDisplay = (dateString) => {
  if (!dateString) return ''

  const date = new Date(dateString)
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')

  return `${hours}:${minutes}`
}
const formatDate = (dateString) => {
  if (!dateString) return '' // Handle undefined, null, or empty date strings

  const date = new Date(dateString)
  if (isNaN(date.getTime())) {
    // Handle invalid date cases
    return ''
  }

  return format(date, 'yyyy-MM-dd') // Assuming you're using date-fns
}

const Matrimonials = () => {
  const [matrimonialProfiles, setmatrimonialProfiles] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [selectedMatrimonialId, setSelectedMatrimonialId] = useState(null)
  const [editMode, setEditMode] = useState(false)
  const [file, setFile] = useState(null)
  const [togglingStatus, setTogglingStatus] = useState(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [limit, setLimit] = useState(10)
  const [uploading, setUploading] = useState(false)
  const [isPopupOpen, setIsPopupOpen] = useState(false)
  const [newMatrimonial, setNewMatrimonial] = useState({
    matrimonialId: '',
    firstName: '',
    middleName: '',
    lastName: '',
    contactNumber: '',
    dateOfBirth: '',
    age: '',
    profilePic: '',
    biodata: '',
    status: '',
  })
  const backendUrl = getBackendURL()

  useEffect(() => {
    fetchData()
  }, [])

  const handleMoreDetails = (matrimonialId) => {
    // Toggle visibility of details
    setSelectedMatrimonialId(selectedMatrimonialId === matrimonialId ? null : matrimonialId)
  }
  const fetchData = async (page = 1, limit = 10) => {
    try {
      const response = await axios.get(`${backendUrl}/apis/matrimonialprofiles`, {
        params: {
          page: page,
          limit: limit,
        },
      })
      if (response.data && response.data.matrimonialProfiles) {
        setmatrimonialProfiles(response.data.matrimonialProfiles)
        setTotalPages(response.data.totalPages)
        setCurrentPage(response.data.currentPage)
      } else {
        console.error('Unexpected response structure:', response)
      }
    } catch (error) {
      console.error('Error fetching data:', error)
    }
  }
  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      fetchData(page, limit)
    }
  }

  const getPagesToShow = () => {
    const pages = []

    if (totalPages <= 3) {
      // If there are 3 or fewer pages, show all pages
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i)
      }
    } else {
      // Always show current page, and one before and one after
      if (currentPage > 1) pages.push(currentPage - 1)
      pages.push(currentPage)
      if (currentPage < totalPages) pages.push(currentPage + 1)

      // Ensure we don't exceed the total number of pages
      pages.forEach((page) => {
        if (page < 1) pages.push(1)
        if (page > totalPages) pages.push(totalPages)
      })
    }

    return Array.from(new Set(pages)).sort((a, b) => a - b) // Remove duplicates and sort
  }

  const pagesToShow = getPagesToShow()

  const togglePopup = (e) => {
    e.preventDefault()
    setIsPopupOpen(!isPopupOpen)
    fetchData()
  }

  const handleToggleStatus = async (matrimonialId) => {
    setTogglingStatus(matrimonialId) // Indicate which user status is being toggled
    try {
      // Toggle user status
      await axios.put(`${backendUrl}/apis/togglematrimonialstatus/${matrimonialId}`)

      await fetchData()
    } catch (error) {
      console.error(
        'Error toggling user status:',
        error.response ? error.response.data : error.message,
      )
    } finally {
      setTogglingStatus(null) // Reset toggling status
    }
  }

  // Handle file upload
  const handleUploadCSV = async (e) => {
    e.preventDefault()
    setIsPopupOpen(!isPopupOpen)
    if (!file) {
      alert('No file chosen')
      return
    }

    const formData = new FormData()
    formData.append('csvFile', file) // Key should match the server-side key

    try {
      const response = await axios.post(`${backendUrl}/apis/addmatrimonialsfromcsv`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })

      // Handle successful response
      console.log('Upload successful:', response.data) // For debugging
      alert('File uploaded successfully.')
      // setShowModal(false)
      fetchData()
    } catch (error) {
      // Handle errors
      console.error('Error uploading file:', error.response ? error.response.data : error.message)
      alert('Failed to upload file.')
    } finally {
      setUploading(false) // Reset uploading status after processing
    }
  }

  const handleFileChange = (matrimonial) => {
    setFile(matrimonial.target.files[0])
  }

  const handleEdit = async (id) => {
    console.log(`Edit matrimonialprofile with ID: ${id}`)
    setEditMode(true) // Set edit mode to true
    try {
      const response = await axios.get(`${backendUrl}/apis/matrimonialdetails?matrimonialId=${id}`)
      const matrimonialData = response.data.matrimonialProfile
      console.log('DATA: ', matrimonialData)

      setNewMatrimonial({
        matrimonialId: matrimonialData.matrimonialId, // Include id for updating
        firstName: matrimonialData.firstName,
        middleName: matrimonialData.middleName,
        // age: matrimonialData.age,
        age: calculateAge(matrimonialData.dateOfBirth),
        lastName: matrimonialData.lastName,
        dateOfBirth: matrimonialData.dateOfBirth,
        contactNumber: matrimonialData.contactNumber,
        profilePic: matrimonialData.profilePic,
        biodata: matrimonialData.biodata,
        status: matrimonialData.status,
      })
      setShowForm(true) // Open the form for editing
    } catch (error) {
      console.error('Error fetching matrimonial details:', error)
      alert('Error fetching matrimonial details. Please try again later.')
    }
  }

  // const handleDelete = async (id) => {
  //   const userConfirmed = window.confirm('Are you sure you want to delete this matrimonialprofile?')

  //   if (!userConfirmed) {
  //     return // Exit the function if the user cancels the deletion
  //   }

  //   try {
  //     const response = await axios.put(`${backendUrl}/apis/deletematrimonial/${id}`)
  //     if (response.status === 200) {
  //       setmatrimonialProfiles(
  //         matrimonialProfiles.filter((matrimonial) => matrimonialProfiles.matrimonialId !== id),
  //       )
  //     } else {
  //       console.error('Failed to delete matrimonialprofile:', response)
  //       alert('Failed to delete matrimonialprofile. Please try again.')
  //     }
  //   } catch (error) {
  //     console.error('Error deleting matrimonialprofile:', error)
  //     alert('Error deleting matrimonialprofile. Please try again.')
  //   }
  // }

  const handleDelete = async (id) => {
    const userConfirmed = window.confirm(
      'Are you sure you want to delete this matrimonial profile?',
    )

    if (!userConfirmed) {
      return // Exit the function if the user cancels the deletion
    }

    try {
      const response = await axios.put(`${backendUrl}/apis/deletematrimonial/${id}`)
      if (response.status === 200) {
        setmatrimonialProfiles((prevProfiles) =>
          prevProfiles.filter((matrimonial) => matrimonial.matrimonialId !== id),
        )
      } else {
        console.error('Failed to delete matrimonial profile:', response)
        alert('Failed to delete matrimonial profile. Please try again.')
      }
    } catch (error) {
      console.error('Error deleting matrimonial profile:', error)
      alert('Error deleting matrimonial profile. Please try again.')
    }
  }

  const handleAddMatrimonial = () => {
    setShowForm(!showForm)
    setNewMatrimonial({
      matrimonialId: '',
      firstName: '',
      middleName: '',
      lastName: '',
      contactNumber: '',
      dateOfBirth: '',
      age: '',
      profilePic: '',
      biodata: '',
      status: '',
    })
    setEditMode(false)
  }

  // const handleInputChange = (e) => {
  //   const { id, value } = e.target
  //   setNewAnnouncement((prevState) => ({
  //     ...prevState,
  //     [id]: value,
  //   }))
  // }

  const handleInputChange = async (e) => {
    const { name, value, type, files } = e.target

    setNewMatrimonial((prevProfile) => {
      const updatedProfile = { ...prevProfile }

      // Handle file inputs
      if (type === 'file') {
        if (files && files.length > 0) {
          updatedProfile[name] = files[0] // Store the file (photo or PDF)
        } else {
          updatedProfile[name] = prevProfile[name] // Retain previous file (photo or PDF)
        }
      } else {
        // Handle other input types (e.g., text, date)
        updatedProfile[name] = value

        // Calculate age if the date of birth is changed
        if (name === 'dateOfBirth') {
          updatedProfile.age = calculateAge(value)
          console.log('Updated age:', updatedProfile.age)
        }
      }

      return updatedProfile
    })
  }

  const handleFormSubmit = async (e) => {
    e.preventDefault()
    console.log('Form submit handler called')

    // Prepare form data
    const formData = new FormData()
    console.log('newMatrimonial before FormData append:', newMatrimonial)

    // Object.keys(newMatrimonial).forEach((key) => {
    //   if (newMatrimonial[key]) {
    //     console.log(`Key: ${key}, Value: ${newMatrimonial[key]}`)
    //     formData.append(key, newMatrimonial[key])
    //   } else {
    //     console.warn(`${key} is empty or undefined`)
    //   }
    // })

    // // Log FormData
    // for (let [key, value] of formData.entries()) {
    //   console.log(`${key}:`, value)
    // }

    // for (let pair of formData.entries()) {
    //   console.log(`${pair[0]}: ${pair[1]}`)
    // }

    Object.keys(newMatrimonial).forEach((key) => {
      // Check if the value is not undefined or null
      if (newMatrimonial[key] !== undefined && newMatrimonial[key] !== null) {
        console.log(`Key: ${key}, Value: ${newMatrimonial[key]}`)
        formData.append(key, newMatrimonial[key])
      } else {
        console.warn(`${key} is empty or undefined`)
      }
    })

    // Log FormData entries
    for (let [key, value] of formData.entries()) {
      console.log(`${key}:`, value)
    }

    for (let pair of formData.entries()) {
      console.log(`${pair[0]}: ${pair[1]}`)
    }

    console.log('Age in newMatrimonial:', newMatrimonial.age)

    try {
      let response

      if (editMode) {
        console.log('Updating matrimonial profile...')
        // Update announcement
        response = await axios.put(
          `${backendUrl}/apis/editmatrimonial/${newMatrimonial.matrimonialId}`,
          formData,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
            timeout: 30000,
          },
        )
      } else {
        // console.log(formData)
        console.log('Adding new matrimonial...')
        // Add new announcement
        response = await axios.post(`${backendUrl}/apis/addmatrimonial`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
          timeout: 30000,
        })
      }

      console.log(editMode ? 'Edit Response:' : 'Add Response:', response)

      if (response.status === 200 || response.status === 201) {
        alert(editMode ? 'Matrimonial updated successfully' : 'Matrimonial added successfully')

        // Construct the announcement object from the response
        const updatedMatrimonial = {
          matrimonialId: response.data.matrimonialId, // Assuming this is returned from the API
          ...newMatrimonial,
        }

        console.log('Updated Matrimonial:', updatedMatrimonial) // Log updatedAnnouncement to ensure it’s constructed correctly

        setmatrimonialProfiles((prevMatrimonials) =>
          editMode
            ? prevMatrimonials.map((matrimonial) =>
                matrimonial.matrimonialId === updatedMatrimonial.matrimonialId
                  ? updatedMatrimonial
                  : matrimonial,
              )
            : [...prevMatrimonials, updatedMatrimonial],
        )
      } else {
        alert(editMode ? 'Error updating matrimonial' : 'Error adding matrimonial')
      }

      // Reset form after successful submission
      setNewMatrimonial({
        matrimonialId: '',
        firstName: '',
        middleName: '',
        lastName: '',
        contactNumber: '',
        dateOfBirth: '',
        age: '',
        profilePic: '',
        biodata: '',
        status: '',
      })
      setShowForm(false)
      setEditMode(false) // Reset edit mode
      fetchData() // Refetch data to reflect changes
    } catch (error) {
      console.error('Error submitting matrimonial:', error)
      if (error.response) {
        alert(`Error: ${error.response.data.error || 'Server Error'}`)
      } else if (error.request) {
        alert('No response received from server. Please try again later.')
      } else {
        alert(`Error: ${error.message}`)
      }
    }
  }

  return (
    <CRow>
      <CCol xs={12}>
        <CCard className="mb-4">
          <CCardHeader className="d-flex justify-content-between align-items-center">
            <strong>
              {showForm ? (editMode ? 'Edit Matrimonial' : 'Add Matrimonial') : 'Matrimonial List'}
            </strong>
            <div>
              {!showForm && (
                <>
                  {/* <CButton color="primary" onClick={togglePopup} style={{ marginRight: '11px' }}>
                    Import
                  </CButton> */}
                  <CButton color="primary" onClick={handleAddMatrimonial}>
                    Add Matrimonial
                  </CButton>
                </>
              )}
            </div>
          </CCardHeader>
          {isPopupOpen && (
            <div
              style={{
                position: 'fixed',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: '500px',
                height: '300px',
                backgroundColor: '#fff',
                boxShadow: '0 0 15px rgba(0, 0, 0, 0.3)',
                zIndex: 1050,
                borderRadius: '8px',
                padding: '20px',
              }}
            >
              <CCard>
                <CCardHeader>Upload CSV File</CCardHeader>
                <CCardBody>
                  <input
                    type="file"
                    accept=".csv"
                    onChange={handleFileChange}
                    style={{ display: 'block', marginBottom: '15px' }}
                  />
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      marginTop: '100px',
                    }}
                  >
                    <CButton
                      color="primary"
                      onClick={handleUploadCSV}
                      style={{
                        width: '49%', // Adjusts button width to fit side by side
                      }}
                    >
                      Upload
                    </CButton>
                    <CButton
                      color="secondary"
                      onClick={togglePopup}
                      style={{
                        width: '49%', // Adjusts button width to fit side by side
                      }}
                    >
                      Close
                    </CButton>
                  </div>
                </CCardBody>
              </CCard>
            </div>
          )}
          <CCardBody>
            {showForm && (
              <CForm className="row g-3 mb-4" onSubmit={handleFormSubmit}>
                <CCol md={6}>
                  <CFormInput
                    type="text"
                    id="firstName"
                    name="firstName"
                    label="firstName"
                    value={newMatrimonial.firstName}
                    onChange={handleInputChange}
                    required
                  />
                </CCol>
                <CCol md={6}>
                  <CFormInput
                    type="text"
                    id="middleName"
                    name="middleName"
                    label="middleName"
                    value={newMatrimonial.middleName}
                    onChange={handleInputChange}
                    required
                  ></CFormInput>
                </CCol>
                <CCol md={6}>
                  <CFormInput
                    type="text"
                    id="lastName"
                    name="lastName"
                    label="lastName"
                    value={newMatrimonial.lastName}
                    onChange={handleInputChange}
                    required
                  ></CFormInput>
                </CCol>
                <CCol md={6}>
                  <CFormInput
                    type="date"
                    id="dateOfBirth"
                    name="dateOfBirth"
                    label="dateOfBirth"
                    value={formatDate(newMatrimonial.dateOfBirth) || ''}
                    onChange={handleInputChange}
                    // min={getMinDate()}
                    max={getMaxDateOfBirth()}
                    required
                  />
                </CCol>
                <CCol md="6">
                  <label htmlFor="age" className="form-label">
                    Age <span className="text-danger">*</span>
                  </label>
                  <input
                    type="number"
                    className="form-control"
                    id="age"
                    name="age"
                    value={newMatrimonial.age}
                    onChange={handleInputChange}
                    readOnly
                  />
                </CCol>
                <CCol md="6">
                  <label htmlFor="photo" className="form-label">
                    ProfilePic <span className="text-danger">*</span>
                  </label>
                  {editMode && newMatrimonial.profilePic && (
                    <div className="mb-3">
                      <img
                        src={`http://157.173.221.111:7777/communityapp.com/backend/${newMatrimonial.profilePic}`}
                        alt="User Photo"
                        style={{ maxWidth: '100%', maxHeight: '100px', borderRadius: '5px' }}
                      />
                    </div>
                  )}
                  <input
                    type="file"
                    className="form-control"
                    id="profilePic"
                    name="profilePic"
                    accept=".jpg, .jpeg, .png"
                    onChange={handleInputChange}
                  />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputPDF">Biodata</CFormLabel>
                  <CFormInput
                    type="file"
                    id="biodata"
                    name="biodata"
                    onChange={handleInputChange}
                    // required
                    accept=".pdf"
                  />
                </CCol>
                <CCol md="6">
                  <label htmlFor="contactNumber" className="form-label">
                    Contact Number <span className="text-danger">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="contactNumber"
                    name="contactNumber"
                    value={newMatrimonial.contactNumber}
                    onChange={handleInputChange}
                    maxLength={10}
                  />
                </CCol>
                <CCol md="12" className="d-flex justify-content-end">
                  <CButton
                    type="submit"
                    color="primary"
                    className="me-2"
                    onClick={() => console.log('Submit button clicked')}
                  >
                    Submit
                  </CButton>
                  <CButton type="button" color="secondary" onClick={() => setShowForm(false)}>
                    Cancel
                  </CButton>
                </CCol>
              </CForm>
            )}
            {!showForm && (
              <>
                <CTable hover responsive>
                  <CTableHead>
                    <CTableRow>
                      <CTableHeaderCell scope="col">Id</CTableHeaderCell>
                      <CTableHeaderCell scope="col">Photo</CTableHeaderCell>
                      <CTableHeaderCell scope="col">Name</CTableHeaderCell>
                      <CTableHeaderCell scope="col">ContactNumber</CTableHeaderCell>
                      <CTableHeaderCell scope="col">BirthDate</CTableHeaderCell>
                      <CTableHeaderCell scope="col">Actions</CTableHeaderCell>
                    </CTableRow>
                  </CTableHead>
                  <CTableBody>
                    {matrimonialProfiles.map((matrimonial, index) => (
                      <React.Fragment key={matrimonial.matrimonialId}>
                        <CTableRow>
                          <CTableDataCell>{index + 1}</CTableDataCell>
                          <CTableDataCell>
                            {matrimonial.profilePic ? (
                              <img
                                src={
                                  `http://157.173.221.111:7777/communityapp.com/backend/${matrimonial.profilePic}` ||
                                  ''
                                }
                                alt="photo"
                                style={{
                                  width: '50px',
                                  height: '50px',
                                  objectFit: 'cover',
                                  borderRadius: '50%',
                                }}
                              />
                            ) : (
                              'No photo'
                            )}
                          </CTableDataCell>
                          <CTableDataCell>
                            <span
                              style={{ cursor: 'pointer', color: 'blue' }}
                              onClick={() => handleMoreDetails(matrimonial.matrimonialId)}
                            >
                              {`${matrimonial.firstName} ${matrimonial.lastName}`}
                            </span>
                          </CTableDataCell>
                          <CTableDataCell>{matrimonial.contactNumber}</CTableDataCell>
                          <CTableDataCell>
                            {formatDateForDisplay(matrimonial.dateOfBirth)}
                          </CTableDataCell>
                          <CTableDataCell>
                            <div className="d-flex align-items-center">
                              <CButton
                                color="primary"
                                size="sm"
                                className="me-1"
                                onClick={() => handleEdit(matrimonial.matrimonialId)}
                              >
                                <CIcon icon={cilPencil} />
                              </CButton>
                              <CButton
                                color="danger"
                                size="sm"
                                onClick={() => handleDelete(matrimonial.matrimonialId)}
                              >
                                <CIcon icon={cilTrash} />
                              </CButton>
                              <CButton
                                // color="secondary"
                                size="sm"
                                className="ms-2"
                                onClick={() => handleToggleStatus(matrimonial.matrimonialId)}
                                disabled={togglingStatus === matrimonial.matrimonialId}
                              >
                                <IoToggle
                                  size={24} // Set the size of the icon
                                  style={{
                                    color: matrimonial.status == '1' ? 'green' : 'grey',
                                    transform:
                                      matrimonial.status == '1' ? 'rotate(0deg)' : 'rotate(180deg)',
                                    // transition: 'transform 0.1s',
                                  }}
                                />
                              </CButton>
                            </div>
                          </CTableDataCell>
                        </CTableRow>
                        <CTableRow>
                          <CTableDataCell colSpan="9">
                            <CCollapse
                              visible={selectedMatrimonialId === matrimonial.matrimonialId}
                            >
                              <CCard>
                                <CCardBody>
                                  <CRow className="mb-3">
                                    <CCol md="6">
                                      <strong>First Name:</strong> {matrimonial.firstName}
                                    </CCol>
                                    <CCol md="6">
                                      <strong>Middle Name:</strong> {matrimonial.middleName}
                                    </CCol>
                                  </CRow>

                                  <CRow className="mb-3">
                                    <CCol md="6">
                                      <strong>Last Name:</strong> {matrimonial.lastName}
                                    </CCol>
                                    <CCol md="6">
                                      <strong>Birth Date:</strong>{' '}
                                      {formatDateForDisplay(matrimonial.dateOfBirth)}
                                    </CCol>
                                  </CRow>

                                  <CRow className="mb-3">
                                    <CCol md="12">
                                      <strong>Contact Number:</strong> {matrimonial.contactNumber}
                                    </CCol>
                                  </CRow>

                                  <CRow className="mb-3">
                                    <CCol md="12">
                                      <strong>Profile Picture:</strong>
                                      {matrimonial.profilePic && (
                                        <div style={{ marginTop: '10px' }}>
                                          <img
                                            src={`http://157.173.221.111:7777/communityapp.com/backend/${matrimonial.profilePic}`}
                                            alt="Profile Pic"
                                            style={{
                                              maxWidth: '100px',
                                              maxHeight: '100px',
                                              marginTop: '10px',
                                            }}
                                          />
                                        </div>
                                      )}
                                    </CCol>
                                  </CRow>

                                  <CRow className="mb-3">
                                    <CCol md="12">
                                      <strong>BioData:</strong>&nbsp;&nbsp;
                                      <a
                                        href={`http://157.173.221.111:7777/communityapp.com/backend/${matrimonial.biodata}`}
                                        download
                                        target="_blank"
                                        rel="noopener noreferrer"
                                      >
                                        Download PDF
                                      </a>
                                    </CCol>
                                  </CRow>
                                </CCardBody>
                              </CCard>
                            </CCollapse>
                          </CTableDataCell>
                        </CTableRow>
                      </React.Fragment>
                    ))}
                  </CTableBody>
                </CTable>
                <CPagination align="end" aria-label="Page navigation example">
                  <CPaginationItem
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                    style={{ cursor: currentPage === 1 ? 'default' : 'pointer' }} // Pointer cursor for enabled
                  >
                    Previous
                  </CPaginationItem>
                  {pagesToShow.map((page) => (
                    <CPaginationItem
                      key={page}
                      onClick={() => handlePageChange(page)}
                      active={page === currentPage}
                      style={{ cursor: 'pointer' }} // Pointer cursor for all items
                    >
                      {page}
                    </CPaginationItem>
                  ))}
                  <CPaginationItem
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    style={{ cursor: currentPage === totalPages ? 'default' : 'pointer' }} // Pointer cursor for enabled
                  >
                    Next
                  </CPaginationItem>
                </CPagination>
              </>
            )}
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}

export default Matrimonials
