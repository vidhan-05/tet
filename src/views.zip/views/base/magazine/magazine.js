import { cilPencil, cilTrash } from '@coreui/icons'
import CIcon from '@coreui/icons-react'
import {
  CButton,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CCollapse,
  CForm,
  CFormInput,
  CFormLabel,
  CFormTextarea,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
} from '@coreui/react'
import axios from 'axios'
import { format } from 'date-fns'
import React, { useEffect, useState } from 'react'
import { IoToggle } from 'react-icons/io5'
import { getBackendURL } from '../../../util'

const formatDateForDisplay = (dateString) => {
  if (!dateString) return ''

  const date = new Date(dateString)
  const day = String(date.getDate()).padStart(2, '0')
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const year = date.getFullYear()

  return `${day}-${month}-${year}`
}

const formatDate = (dateString) => {
  if (!dateString) return '' // Handle undefined, null, or empty date strings

  const date = new Date(dateString)
  if (isNaN(date.getTime())) {
    // Handle invalid date cases
    return ''
  }

  return format(date, 'yyyy-MM-dd') // Assuming you're using date-fns
}

const Magazines = () => {
  const [magazines, setMagazines] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [selectedMagazineId, setSelectedMagazineId] = useState(null)
  const [editMode, setEditMode] = useState(false)
  const [file, setFile] = useState(null)
  const [togglingStatus, setTogglingStatus] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [isPopupOpen, setIsPopupOpen] = useState(false)
  const [newMagazine, setNewMagazine] = useState({
    magazineId: '',
    title: '',
    description: '',
    date: '',
    magazine: '', // Holds the selected PDF file
  })
  const backendUrl = getBackendURL()
  useEffect(() => {
    // Fetch magazines from API on component mount
    fetchData()
  }, [])

  const handleMoreDetails = (magazineId) => {
    // Toggle visibility of details
    setSelectedMagazineId(selectedMagazineId === magazineId ? null : magazineId)
  }
  const fetchData = async () => {
    try {
      const response = await axios.get(`${backendUrl}/apis/magazines`)
      if (response.data && response.data.magazines) {
        setMagazines(response.data.magazines)
      } else {
        console.error('Unexpected response structure:', response)
      }
    } catch (error) {
      console.error('Error fetching data:', error)
    }
  }

  const togglePopup = (e) => {
    e.preventDefault()
    setIsPopupOpen(!isPopupOpen)
    fetchData()
  }

  const handleToggleStatus = async (magazineId) => {
    setTogglingStatus(magazineId) // Indicate which user status is being toggled
    try {
      // Toggle user status
      await axios.put(`${backendUrl}/apis/togglemagazinestatus/${magazineId}`)

      await fetchData()
    } catch (error) {
      console.error(
        'Error toggling user status:',
        error.response ? error.response.data : error.message,
      )
    } finally {
      setTogglingStatus(null) // Reset toggling status
    }
  }

  // Handle file upload
  const handleUploadCSV = async (e) => {
    e.preventDefault()
    setIsPopupOpen(!isPopupOpen)
    if (!file) {
      alert('No file chosen')
      return
    }

    const formData = new FormData()
    formData.append('csvFile', file) // Key should match the server-side key

    try {
      const response = await axios.post(`${backendUrl}/apis/addmagazinesfromcsv`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })

      // Handle successful response
      console.log('Upload successful:', response.data) // For debugging
      alert('File uploaded successfully.')
      // setShowModal(false)
      fetchData()
    } catch (error) {
      // Handle errors
      console.error('Error uploading file:', error.response ? error.response.data : error.message)
      alert('Failed to upload file.')
    } finally {
      setUploading(false) // Reset uploading status after processing
    }
  }

  const handleFileChange = (magazine) => {
    setFile(magazine.target.files[0])
  }

  const handleEdit = async (id) => {
    console.log(`Edit magazine with ID: ${id}`)
    setEditMode(true) // Set edit mode to true
    try {
      const response = await axios.get(`${backendUrl}/apis/magazinedetails?magazineId=${id}`)
      const magazineData = response.data.magazine
      console.log('DATA: ', magazineData)

      setNewMagazine({
        magazineId: magazineData.magazineId, // Include id for updating
        title: magazineData.title,
        description: magazineData.description,
        date: magazineData.date,
      })
      setShowForm(true) // Open the form for editing
    } catch (error) {
      console.error('Error fetching magazine details:', error)
      alert('Error fetching magazine details. Please try again later.')
    }
  }

  const handleDelete = async (id) => {
    const userConfirmed = window.confirm('Are you sure you want to delete this magazine?')

    if (!userConfirmed) {
      return // Exit the function if the user cancels the deletion
    }

    try {
      const response = await axios.put(`${backendUrl}/apis/deletemagazine/${id}`)
      if (response.status === 200) {
        setMagazines(magazines.filter((magazine) => magazine.magazineId !== id))
      } else {
        console.error('Failed to delete magazine:', response)
        alert('Failed to delete magazine. Please try again.')
      }
    } catch (error) {
      console.error('Error deleting magazine:', error)
      alert('Error deleting magazine. Please try again.')
    }
  }

  const handleAddMagazine = () => {
    setShowForm(!showForm)
    setNewMagazine({
      title: '',
      description: '',
      date: '',
      magazine: '',
    })
    setEditMode(false)
  }

  // const handleInputChange = (e) => {
  //   const { id, value } = e.target
  //   setNewMagazine((prevState) => ({
  //     ...prevState,
  //     [id]: value,
  //   }))
  // }

  // const handleInputChange = (e) => {
  //   const { id, value, files } = e.target

  //   // If the input is a file input (for the PDF)
  //   if (id === 'magazine' && files.length > 0) {
  //     const file = files[0]
  //     setNewMagazine((prevState) => ({
  //       ...prevState,
  //       [id]: file,
  //     }))
  //   } else {
  //     // Handle other inputs
  //     setNewMagazine((prevState) => ({
  //       ...prevState,
  //       [id]: value,
  //     }))
  //   }
  // }

  const handleInputChange = async (e) => {
    const { name, value, type, files } = e.target

    setNewMagazine((prevMagazine) => {
      const updatedMagazine = { ...prevMagazine }

      // Handle file inputs specifically for PDFs
      if (type === 'file') {
        if (files && files.length > 0) {
          updatedMagazine[name] = files[0]
        } else {
          updatedMagazine[name] = prevMagazine.magazine // Retain the previous PDF file
        }
      } else {
        // Handle other input types (e.g., text, date)
        updatedMagazine[name] = value
      }

      return updatedMagazine
    })
  }

  // const handleFormSubmit = async (e) => {
  //   e.preventDefault()
  //   console.log('Form submit handler called')

  //   // // Prepare form data
  //   // const formData = new FormData()
  //   // console.log('newMagazine before FormData append:', newMagazine)

  //   // Object.keys(newMagazine).forEach((key) => {
  //   //   if (newMagazine[key]) {
  //   //     formData.append(key, newMagazine[key])
  //   //   } else {
  //   //     console.warn(`${key} is empty or undefined`)
  //   //   }
  //   // })
  //   const formData = new FormData()
  //   formData.append('title', newMagazine.title)
  //   formData.append('description', newMagazine.description)
  //   formData.append('date', newMagazine.date)
  //   formData.append('magazine', newMagazine.magazine)

  //   // Log FormData
  //   for (let [key, value] of formData.entries()) {
  //     console.log(`${key}:`, value)
  //   }

  //   for (let pair of formData.entries()) {
  //     console.log(`${pair[0]}: ${pair[1]}`)
  //   }

  //   try {
  //     let response

  //     if (editMode) {
  //       console.log('Updating magazine...')
  //       // Update magazine
  //       response = await axios.put(
  //         `${backendUrl}/apis/editmagazine/${newMagazine.magazineId}`,
  //         formData,
  //         {
  //           headers: {
  //             'Content-Type': 'multipart/form-data',
  //           },
  //           timeout: 30000,
  //         },
  //       )
  //     } else {
  //       console.log(formData)
  //       console.log('Adding new magazine...')
  //       // Add new magazine
  //       response = await axios.post(`${backendUrl}/apis/addmagazine`, formData, {
  //         headers: {
  //           'Content-Type': 'multipart/form-data',
  //         },
  //         timeout: 30000,
  //       })
  //     }

  //     console.log(editMode ? 'Edit Response:' : 'Add Response:', response)

  //     if (response.status === 200 || response.status === 201) {
  //       alert(editMode ? 'Magazine updated successfully' : 'Magazine added successfully')

  //       // Construct the magazine object from the response
  //       const updatedMagazine = {
  //         magazineId: response.data.magazineId, // Assuming this is returned from the API
  //         ...newMagazine,
  //       }

  //       console.log('Updated Magazine:', updatedMagazine) // Log updatedMagazine to ensure it’s constructed correctly

  //       setMagazines((prevMagazines) =>
  //         editMode
  //           ? prevMagazines.map((magazine) =>
  //               magazine.magazineId === updatedMagazine.magazineId ? updatedMagazine : magazine,
  //             )
  //           : [...prevMagazines, updatedMagazine],
  //       )
  //     } else {
  //       alert(editMode ? 'Error updating magazine' : 'Error adding magazine')
  //     }

  //     // Reset form after successful submission
  //     setNewMagazine({
  //       title: '',
  //       description: '',
  //       date: '',
  //       magazine: '',
  //     })
  //     setShowForm(false)
  //     setEditMode(false) // Reset edit mode
  //     fetchData() // Refetch data to reflect changes
  //   } catch (error) {
  //     console.error('Error submitting magazine:', error)
  //     if (error.response) {
  //       alert(`Error: ${error.response.data.error || 'Server Error'}`)
  //     } else if (error.request) {
  //       alert('No response received from server. Please try again later.')
  //     } else {
  //       alert(`Error: ${error.message}`)
  //     }
  //   }
  // }

  const handleFormSubmit = async (event) => {
    event.preventDefault()
    console.log('Form submit handler called')

    // const errors = validateForm()
    // if (Object.keys(errors).length > 0) {
    //   setFormErrors(errors)
    //   return
    // }

    const formData = new FormData()
    console.log('newMagazine before FormData append:', newMagazine)

    Object.keys(newMagazine).forEach((key) => {
      if (newMagazine[key]) {
        formData.append(key, newMagazine[key])
      } else {
        console.warn(`${key} is empty or undefined`)
      }
    })
    for (let [key, value] of formData.entries()) {
      console.log(`${key}:`, value)
    }

    try {
      console.log('Is editMode:', editMode)

      let response

      if (editMode) {
        console.log('Updating magazine...')
        console.log(formData)
        // Call edit magazine API
        response = await axios.put(
          `${backendUrl}/apis/editmagazine/${newMagazine.magazineId}`,
          formData,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
            timeout: 30000,
          },
        )
      } else {
        console.log('Adding new magazine...')
        // Call add magazine API
        response = await axios.post(`${backendUrl}/apis/addmagazine`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
          timeout: 30000,
        })
      }

      console.log(editMode ? 'Edit Response:' : 'Add Response:', response)

      if (response.status === 200 || response.status === 201) {
        alert(editMode ? 'Magazine updated successfully' : 'Magazine added successfully')

        // Construct the magazine object from the response
        const updatedMagazine = {
          magazineId: response.data.magazineId, // Assuming this is returned from the API
          ...newMagazine,
          magazine: newMagazine.magazine ? newMagazine.magazine.name : '', // Ensure magazine (PDF) exists
        }

        console.log('Updated Magazine:', updatedMagazine) // Log updatedMagazine to ensure it’s constructed correctly

        setMagazines((prevMagazines) =>
          editMode
            ? prevMagazines.map((magazine) =>
                magazine.magazineId === updatedMagazine.magazineId ? updatedMagazine : magazine,
              )
            : [...prevMagazines, updatedMagazine],
        )
      } else {
        alert(editMode ? 'Error updating magazine' : 'Error adding magazine')
      }

      // Reset form after successful submission
      setNewMagazine({
        magazineId: '',
        title: '',
        description: '',
        date: '',
        magazine: '',
      })
      // setFormErrors({})
      setShowForm(false)
      fetchData() // Refresh the magazine list
    } catch (error) {
      console.error('Error submitting form:', error)
      if (error.response) {
        alert(`Error: ${error.response.data.error || 'Server Error'}`)
      } else if (error.request) {
        alert('No response received from server. Please try again later.')
      } else {
        alert(`Error: ${error.message}`)
      }
    }
  }

  return (
    <CRow>
      <CCol xs={12}>
        <CCard className="mb-4">
          <CCardHeader className="d-flex justify-content-between align-items-center">
            <strong>
              {showForm ? (editMode ? 'Edit Magazine' : 'Add Magazine') : 'Magazine List'}
            </strong>
            <div>
              {!showForm && (
                <>
                  {/* <CButton color="primary" onClick={togglePopup} style={{ marginRight: '11px' }}>
                    Import
                  </CButton> */}
                  <CButton color="primary" onClick={handleAddMagazine}>
                    Add Magazine
                  </CButton>
                </>
              )}
            </div>
          </CCardHeader>
          {isPopupOpen && (
            <div
              style={{
                position: 'fixed',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: '500px',
                height: '300px',
                backgroundColor: '#fff',
                boxShadow: '0 0 15px rgba(0, 0, 0, 0.3)',
                zIndex: 1050,
                borderRadius: '8px',
                padding: '20px',
              }}
            >
              <CCard>
                <CCardHeader>Upload CSV File</CCardHeader>
                <CCardBody>
                  <input
                    type="file"
                    accept=".csv"
                    onChange={handleFileChange}
                    style={{ display: 'block', marginBottom: '15px' }}
                  />
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      marginTop: '100px',
                    }}
                  >
                    <CButton
                      color="primary"
                      onClick={handleUploadCSV}
                      style={{
                        width: '49%', // Adjusts button width to fit side by side
                      }}
                    >
                      Upload
                    </CButton>
                    <CButton
                      color="secondary"
                      onClick={togglePopup}
                      style={{
                        width: '49%', // Adjusts button width to fit side by side
                      }}
                    >
                      Close
                    </CButton>
                  </div>
                </CCardBody>
              </CCard>
            </div>
          )}
          <CCardBody>
            {showForm && (
              <CForm className="row g-3" onSubmit={handleFormSubmit}>
                <CCol md={6}>
                  <CFormInput
                    type="text"
                    id="title"
                    name="title"
                    label="Title"
                    value={newMagazine.title || ''}
                    onChange={handleInputChange}
                    required
                  />
                </CCol>
                <CCol md={6}>
                  <CFormInput
                    type="date"
                    name="date"
                    id="date"
                    label="Date"
                    value={formatDate(newMagazine.date) || ''}
                    onChange={handleInputChange}
                    required
                  />
                </CCol>
                <CCol xs={12}>
                  <CFormTextarea
                    id="description"
                    name="description"
                    label="Description"
                    value={newMagazine.description || ''}
                    onChange={handleInputChange}
                    rows="4"
                    required
                  />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputPDF">PDF File</CFormLabel>
                  <CFormInput
                    type="file"
                    id="magazine"
                    name="magazine"
                    onChange={handleInputChange}
                    // required
                    accept=".pdf"
                  />
                </CCol>
                <CCol md="12" className="d-flex justify-content-end">
                  <CButton
                    type="submit"
                    color="primary"
                    className="me-2"
                    onClick={() => console.log('Submit button clicked')}
                  >
                    {/* {editMode ? 'Update Event' : 'Add Event'} */}Submit
                  </CButton>
                  <CButton type="button" color="secondary" onClick={() => setShowForm(false)}>
                    Cancel
                  </CButton>
                </CCol>
              </CForm>
            )}
            {!showForm && (
              <CTable hover responsive>
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell scope="col">Id</CTableHeaderCell>
                    <CTableHeaderCell scope="col">Title</CTableHeaderCell>
                    <CTableHeaderCell scope="col">Date</CTableHeaderCell>
                    <CTableHeaderCell scope="col">Description</CTableHeaderCell>
                    {/* <CTableHeaderCell scope="col">PDF File</CTableHeaderCell> */}
                    <CTableHeaderCell scope="col">Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {magazines.map((magazine, index) => (
                    <React.Fragment key={magazine.magazineId}>
                      <CTableRow>
                        <CTableDataCell>{index + 1}</CTableDataCell>
                        <CTableDataCell>
                          <span
                            style={{ cursor: 'pointer', color: 'blue' }}
                            onClick={() => handleMoreDetails(magazine.magazineId)}
                          >
                            {magazine.title}
                          </span>
                        </CTableDataCell>
                        <CTableDataCell>{formatDateForDisplay(magazine.date)}</CTableDataCell>
                        <CTableDataCell>{magazine.description}</CTableDataCell>
                        <CTableDataCell>
                          <CButton
                            color="info"
                            size="sm"
                            className="me-1"
                            onClick={() => handleEdit(magazine.magazineId)}
                          >
                            <CIcon icon={cilPencil} />
                          </CButton>
                          <CButton
                            color="danger"
                            size="sm"
                            onClick={() => handleDelete(magazine.magazineId)}
                          >
                            <CIcon icon={cilTrash} />
                          </CButton>
                          <CButton
                            // color="secondary"
                            size="sm"
                            className="ms-2"
                            onClick={() => handleToggleStatus(magazine.magazineId)}
                            disabled={togglingStatus === magazine.magazineId}
                          >
                            <IoToggle
                              size={24} // Set the size of the icon
                              style={{
                                color: magazine.status == '1' ? 'green' : 'grey',
                                transform:
                                  magazine.status == '1' ? 'rotate(0deg)' : 'rotate(180deg)',
                                // transition: 'transform 0.1s',
                              }}
                            />
                          </CButton>
                        </CTableDataCell>
                      </CTableRow>
                      <CTableRow>
                        <CTableDataCell colSpan="9">
                          <CCollapse visible={selectedMagazineId === magazine.magazineId}>
                            <CCard>
                              <CCardBody>
                                <CRow>
                                  <CCol md="12">
                                    <strong>Title:</strong> {magazine.title}
                                  </CCol>
                                </CRow>
                                <CRow className="mt-2">
                                  <CCol md="6">
                                    <strong>Date:</strong> {formatDateForDisplay(magazine.date)}
                                  </CCol>
                                </CRow>
                                <CRow className="mt-2">
                                  <CCol md="12">
                                    <strong>Description:</strong> {magazine.description}
                                  </CCol>
                                </CRow>
                                {/* <CRow className="mt-2">
                                <CCol md="12">
                                  <strong>magazine:</strong> {magazine.magazine}
                                </CCol>
                              </CRow> */}
                                <CRow className="mt-2">
                                  <CCol md="12">
                                    <strong>Magazine:</strong>&nbsp;&nbsp;
                                    <a
                                      href={`http://157.173.221.111:7777/communityapp.com/backend/${magazine.magazine}`}
                                      download
                                      target="_blank"
                                      rel="noopener noreferrer"
                                    >
                                      View
                                    </a>
                                  </CCol>
                                </CRow>
                              </CCardBody>
                            </CCard>
                          </CCollapse>
                        </CTableDataCell>
                      </CTableRow>
                    </React.Fragment>
                  ))}
                </CTableBody>
              </CTable>
            )}
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}

export default Magazines
